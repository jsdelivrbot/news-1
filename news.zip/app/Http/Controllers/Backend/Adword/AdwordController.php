<?php

namespace App\Http\Controllers\Backend\Adword;

use App\Http\Requests\Backend\Adword\AdwordUpdateRequest;
use App\Models\Adword;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class AdwordController extends Controller
{


}
