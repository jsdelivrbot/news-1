@extends("layouts.backend")
@section("content")

admin panel İndex

@endsection
@push("customJs")


@endpush
@push("customCss")



@endpush

