<?php $__env->startSection("content"); ?>


    <!-- Start Popular News [layout A+D]  -->
    <div class="zm-section bg-white ptb-70">
        <div class="container">
            <div class="row mb-40">
                <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
                    <div class="section-title">
                        <h2 class="h6 header-color inline-block uppercase">Populer Haberler</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5 col-sm-12 col-xs-12 col-lg-6">
                    <div class="zm-posts">
                        <article class="zm-post-lay-a">
                            <div class="zm-post-thumb">
                                <a href="<?php echo e(route("frontend.article.index",["id"=>$onearticle->id,"slug"=>$onearticle->slug])); ?>"><img src="<?php echo e(asset($onearticle->image)); ?>" alt="img"></a>
                            </div>
                            <div class="zm-post-dis">
                                <div class="zm-post-header">
                                    <div class="zm-category"><a href="<?php echo e(route("frontend.article.index",["id"=>$onearticle->category->id,"slug"=>$onearticle->category->slug])); ?>"
                                                                class="bg-cat-1 cat-btn"><?php echo e($onearticle->category->tittle); ?></a>
                                    </div>
                                    <h2 class="zm-post-title h2"><a
                                            href="<?php echo e(route("frontend.article.index",["id"=>$onearticle->id,"slug"=>$onearticle->slug])); ?>"><?php echo e($onearticle->tittle); ?></a></h2>
                                    <div class="zm-post-meta">
                                        <ul>
                                            <li class="s-meta"><a href="<?php echo e(route("frontend.user.index",["id"=>$onearticle->user->id,"name"=>$onearticle->user->name])); ?>"
                                                                  class="zm-author"><?php echo e($onearticle->user->name); ?></a></li>
                                            <li class="s-meta"><a href="#"
                                                                  class="zm-date"><?php echo date("d-m-Y",strtotime($onearticle->created_at)); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="zm-post-content">
                                    <p><?php echo str_limit(strip_tags($onearticle->content),$limit=150,$end="..."); ?></p>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <div class="col-md-7 col-sm-12 col-xs-12 col-lg-6">
                    <div class="zm-posts">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Start single post layout D -->
                            <article class="zm-post-lay-d clearfix">
                                <div class="zm-post-thumb f-left">
                                    <a href="<?php echo e(route("frontend.article.index",["id"=>$article->id,"slug"=>$article->slug])); ?>"><img
                                            src="<?php echo e(asset($article->image)); ?>"
                                            alt="img"></a>
                                </div>
                                <div class="zm-post-dis f-right">
                                    <div class="zm-post-header">
                                        <div class="zm-category"><a
                                                href="<?php echo e(route("frontend.category.index",["id"=>$article->category->id,"slug"=>$article->category->slug])); ?>"
                                                class="bg-cat-<?php echo e(array_rand($colors)); ?> cat-btn"><?php echo e($article->category->tittle); ?></a></div>
                                        <h2 class="zm-post-title"><a
                                                href="<?php echo e(route("frontend.article.index",["id"=>$article->id,"slug"=>$article->slug])); ?>"><?php echo e($article->tittle); ?></a>
                                        </h2>
                                        <div class="zm-post-meta">
                                            <ul>
                                                <li class="s-meta"><a
                                                        href="<?php echo e(route("frontend.user.index",["id"=>$article->user->id,"name"=>$article->user->name])); ?>"
                                                        class="zm-author"><?php echo e($article->user->name); ?></a></li>
                                                <li class="s-meta"><a href="#"
                                                                      class="zm-date"><?php echo e(date("d-m-Y",strtotime($article->created_at))); ?></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <!-- End single post layout D -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Popular News [layout A+D]  -->




    <div class="zm-section bg-white pt-20 pb-40">
        <div class="container">
            <div class="row">
                <!-- Start left side -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 columns">
                    <div class="row mb-40">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="section-title">
                                <h2 class="h6 header-color inline-block uppercase">Yeni Haberler</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="zm-posts">
                            <?php $__currentLoopData = $newarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Start single post layout C -->
                                    <article class="zm-post-lay-c zm-single-post clearfix">
                                        <div class="zm-post-thumb f-left">
                                            <a href="<?php echo e(route("frontend.article.index",["id"=>$newarticle->id,"slug"=>$newarticle->slug])); ?>"><img
                                                    src="<?php echo e($newarticle->image); ?>"
                                                    alt="img"></a>
                                        </div>
                                        <div class="zm-post-dis f-right">
                                            <div class="zm-post-header">
                                                <div class="zm-category"><a
                                                        href="<?php echo e(route("frontend.category.index",["id"=>$newarticle->category->id,"slug"=>$newarticle->category->slug])); ?>"
                                                        class="bg-cat-1 cat-btn"><?php echo e($newarticle->category->tittle); ?></a>
                                                </div>
                                                <h2 class="zm-post-title"><a
                                                        href="<?php echo e(route("frontend.article.index",["id"=>$newarticle->id,"slug"=>$newarticle->slug])); ?>"><?php echo e($newarticle->tittle); ?></a>
                                                </h2>
                                                <div class="zm-post-meta">
                                                    <ul>
                                                        <li class="s-meta"><a
                                                                href="<?php echo e(route("frontend.user.index",["id"=>$newarticle->user->id,"name"=>$newarticle->user->name])); ?>"
                                                                class="zm-author"><?php echo e($newarticle->user->name); ?></a></li>
                                                        <li class="s-meta"><a href="#"
                                                                              class="zm-date"><?php echo e(date("d-M-Y",strtotime($newarticle->created_at))); ?></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="zm-post-content">
                                                    <p><?php echo str_limit(strip_tags($newarticle->content),$limit=100,$end="..."); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                    <!-- End single post layout C -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End left side -->
                <!-- Start Right sidebar -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 sidebar-warp columns">
                    <div class="row">


                        <!-- Start post layout E -->
                        <aside class="zm-post-lay-e-area col-xs-12 col-sm-6 col-md-6 col-lg-12 mt-60 hidden-md">
                            <div class="row mb-40">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="section-title">
                                        <h2 class="h6 header-color inline-block uppercase">En Fazla Yorum Alanlar</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="zm-posts">
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!-- Start single post layout E -->
                                            <article class="zm-post-lay-e zm-single-post clearfix">
                                                <div class="zm-post-thumb f-left">
                                                    <a href="<?php echo e(route("frontend.article.index",["id"=>$comment->article->id,"slug"=>$comment->article->slug])); ?>"><img
                                                            src="<?php echo e(asset($comment->article->image)); ?>"
                                                            alt="img"></a>
                                                </div>
                                                <div class="zm-post-dis f-right">
                                                    <div class="zm-post-header">
                                                        <h2 class="zm-post-title"><a href="blog-single-image.html"><?php echo e($comment->article->tittle); ?></a></h2>
                                                        <div class="zm-post-meta">
                                                            <ul>
                                                                <li class="s-meta"><a href="#" class="zm-author"><?php echo e($comment->user->name); ?></a></li>
                                                                <li class="s-meta"><a href="#" class="zm-date"><?php echo e(date("d-M-Y",strtotime($comment->created_at))); ?></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                            <!-- End single post layout E -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </aside>
                        <!-- Start post layout E -->

                        <!-- Start post layout F -->
                        <aside class="zm-post-lay-e-area col-xs-12 col-sm-6 col-md-6 col-lg-12 mt-60 hidden-md">
                            <div class="row mb-40">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="section-title">
                                        <h2 class="h6 header-color inline-block uppercase">Populer</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="zm-posts">
                                    <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!-- Start single post layout E -->
                                            <article class="zm-post-lay-e zm-single-post clearfix">
                                                <div class="zm-post-thumb f-left">
                                                    <a href="<?php echo e(route("frontend.article.index",["id"=>$pop->id,"slug"=>$pop->slug])); ?>"><img
                                                            src="<?php echo e(asset($pop->image)); ?>"
                                                            alt="img"></a>
                                                </div>
                                                <div class="zm-post-dis f-right">
                                                    <div class="zm-post-header">
                                                        <h2 class="zm-post-title"><a href="<?php echo e(route("frontend.article.index",["id"=>$pop->id,"slug"=>$pop->slug])); ?>"><?php echo e($pop->tittle); ?></a></h2>
                                                        <div class="zm-post-meta">
                                                            <ul>
                                                                <li class="s-meta"><a href="#" class="zm-author"><?php echo e($pop->user->name); ?></a></li>
                                                                <li class="s-meta"><a href="#" class="zm-date"><?php echo e(date("d-M-Y",strtotime($pop->created_at))); ?></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                            <!-- End single post layout E -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </aside>
                        <!-- Start post layout E -->
                    </div>
                </div>
                <!-- End Right sidebar -->
            </div>

            <!-- Start Advertisement -->
            <div class="advertisement">
                <div class="row mt-40">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
                        <a href="#"><img src="assets/frontend/images/ad/2.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            <!-- End Advertisement -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>