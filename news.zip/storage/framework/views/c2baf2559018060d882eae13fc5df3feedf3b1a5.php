<?php $__env->startSection("content"); ?>
    <form action="<?php echo e(route("backend.galery.store")); ?>" method="post" class="dropzone" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>

    <script src="https://rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>

    <link rel="stylesheet" href="https://rawgit.com/enyo/dropzone/master/dist/dropzone.css">

<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>