<?php $__env->startSection("content"); ?>

admin panel İndex

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>