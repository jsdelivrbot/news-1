<?php $__env->startSection("content"); ?>

    <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-th"></i></span>
            <h5>Kategori Yönetimi</h5>

            <div style="padding-top: 3px; padding-right: 11px;" class="text-right">
                <a href="<?php echo e(route("backend.categories.create")); ?>" class="btn btn-success ">Ekle</a>
            </div>
        </div>

        <div class="widget-content nopadding">

            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Kategori Başlık</th>
                    <th>Kategori Türü</th>
                    <th>Kategori Açıklama</th>
                    <th>Düzenle</th>
                    <th>Sil</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e($category->tittle); ?></td>
                        <td>
                            <?php if(!empty($category->ust_id)): ?>
                                Alt Kategori
                            <?php else: ?>
                                Üst Kategori
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($category->description); ?></td>
                        <td class="center">
                            <a href="<?php echo e(route("backend.categories.edit",["id"=>$category->id])); ?>"
                               class="btb btn-primary  btn-mini categoryEdit">Düzenle</a>

                        </td>
                        <td class="center">
                            <button data-id="<?php echo e($category->id); ?>" class="btn btn-danger btn-mini categoryDelete">Sil
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>
    <script>
        $(".categoryDelete").on("click", function () {
            var button = $(this);

            $.ajax({
                type: "post",
                url: "<?php echo e(route("backend.categories.delete")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id")
                },
                success: function (response) {
                    if (response.status == "success") {
                        button.closest("tr").remove();
                    }
                    console.log(response);
                },
                error: function (response) {
                    console.log(response);
                }
            })
        })

    </script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/flot/0.8.3/excanvas.min.js"></script>
    <script src="<?php echo e(asset("assets/backend/js/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/js/jquery.ui.custom.js")); ?>"></script>

    <script src="<?php echo e(asset("assets/backend/js/jquery.dataTables.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/backend/js/matrix.tables.js")); ?>"></script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>

    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/css/uniform.css")); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset("assets/backend/css/select2.css")); ?>"/>

<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>