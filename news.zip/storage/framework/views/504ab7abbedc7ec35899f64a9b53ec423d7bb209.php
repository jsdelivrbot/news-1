<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="zm-section bg-white pt-40 pb-70" style="width:700px;margin:0 auto;">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-5">
                        <div class="section-title-2 mb-40">
                            <h3 class="inline-block uppercase">Kullanıcı Girişi</h3>
                            <p>Aşağıdaki formu Doldurarak Hızlıca Giriş Yapın</p>
                        </div>
                    </div>
                </div>
                <div class="registation-form-wrap">
                    <form action="#">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">

                                <div class="single-input">
                                    <label>Email</label>
                                    <input id="email" type="email"
                                           class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"
                                           value="<?php echo e(old('email')); ?>" required>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>


                                <div class="single-input">
                                    <label>Şifreniz</label>
                                    <input id="password" type="password"
                                           class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                                           required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>

                                <div class="single-input">

                                    <input type="checkbox"
                                           name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Beni Hatırla')); ?>

                                </div>
                            </div>

                        </div>

                        <div class="row ">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Giriş')); ?>

                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Şifremi Unuttum')); ?>

                                </a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>