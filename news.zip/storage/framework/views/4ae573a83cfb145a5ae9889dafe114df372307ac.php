<?php $__env->startSection("content"); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Site Ayarları</h5>
                </div>
                <div class="widget-content nopadding">
                    <form id="settingForm" class="form-horizontal">

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="control-group">
                            <label class="control-label">Link 1</label>
                            <div class="controls">
                                <input type="text" name="link1" class="span11" value="<?php echo e($adword->link1); ?>"/>
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label">Link 1</label>
                            <div class="controls">
                                <input type="text" name="link2" class="span11" value="<?php echo e($adword->link2); ?>"/>
                            </div>
                        </div>


                        <div class="form-actions text-center">
                            <button type="button" id="settingUpdate" class="btn btn-success">Güncelle</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>

    <script>

        
            
                
                    
                
            
        


        $("#settingUpdate").on("click", function () {
            // var form = new FormData($("#settingForm")[0]);

            $(".has-error").removeClass("has-error");
            $(".label-danger").remove();

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            $.ajax({
                type: "post",
                url: "<?php echo e(route("backend.adword.createupdate",["id"=>1])); ?>",
                data: {
                    _token:"<?php echo e(csrf_token()); ?>",
                    link1:$("[name=link1").val(),
                    link2:$("[name=link2").val(),
                },

                success: function (response) {
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });


                },
                error: function (response) {
                    swal.close();

                    $.each(response.responseJSON.errors, function (k, v) {
                        $.each(v, function (kk, vv) {
                            $("[name='" + k + "']").parent().addClass("has-error");
                            $("[name='" + k + "']").parent().append(" <span class=\"label label-danger\">" + vv + "</span>");
                        })
                    });

                }
            })
        })

        /* Yüklenen resmi anlık olarak görmek için */
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#logoImageShow').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#logoImage").change(function () {
            readURL(this);
        });
        /* /Yüklenen resmi anlık olarak görmek için */
    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>