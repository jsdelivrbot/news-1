<?php $__env->startSection("content"); ?>
    <div id="page-content" class="page-wrapper">
        <div class="zm-section single-post-wrap bg-white ptb-70 xs-pt-30">
            <div class="container">
                <div class="row">
                    <!-- Start left side -->
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 columns">
                        <div class="row mb-40">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="section-title">
                                    <h2 class="h6 header-color inline-block uppercase">Populer Haberler</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <!-- Start single post image formate-->
                            <div class="col-md-12">
                                <article class="zm-post-lay-single">
                                    <div class="zm-post-thumb">
                                        <a href="javascript:void(0)"><img src="<?php echo e(asset($article->image)); ?>"
                                                                          alt="img"></a>
                                    </div>
                                    <div class="zm-post-dis">
                                        <div class="zm-post-header">
                                            <h2 class="zm-post-title h2"><a
                                                    href="javascript:void(0)"><?php echo e($article->tittle); ?></a></h2>
                                            <div class="zm-post-meta">
                                                <ul>
                                                    <li class="s-meta"><a
                                                            href="<?php echo e(route("frontend.user.index",["id"=>$article->user->id,"name"=>$article->user->name])); ?>"
                                                            class="zm-author"><?php echo e($article->user->name); ?></a></li>
                                                    <li class="s-meta"><a href="javascript:void(0)"
                                                                          class="zm-date"><?php echo e(date("d-M-Y",strtotime($article->created_at))); ?></a>
                                                    </li>
                                                    <li class="s-meta"><a href="javascript:void(0)"
                                                                          class="zm-date">
                                                            <?php echo e($article->getViews()); ?>

                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="zm-post-content"><?php echo $article->content; ?></div>
                                        <div class="entry-meta-small clearfix ptb-40 mtb-40 border-top border-bottom">

                                            <div class="share-social-link pull-right">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-twitter"></i></a>
                                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                                <a href="#"><i class="fa fa-rss"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                            </div>
                                        </div>

                                    </div>
                                </article>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <aside class="zm-post-lay-a2-area">
                                    <div class="post-title mb-40">
                                        <h2 class="h6 inline-block">Benzer İçerikler</h2>
                                    </div>
                                    <div class="row">
                                        <div class="zm-posts clearfix">
                                            <?php $__currentLoopData = $similerArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similerArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                    <article class="zm-post-lay-a2">
                                                        <div class="zm-post-thumb">
                                                            <a href="<?php echo e(route("frontend.article.index",["id"=>$similerArticle->id,"slug"=>$similerArticle->slug])); ?>"><img
                                                                    src="<?php echo e(asset($similerArticle->image)); ?>"
                                                                    alt="img"></a>
                                                        </div>
                                                        <div class="zm-post-dis">
                                                            <div class="zm-post-header">
                                                                <h2 class="zm-post-title h2"><a
                                                                        href="<?php echo e(route("frontend.article.index",["id"=>$similerArticle->id,"slug"=>$similerArticle->slug])); ?>"><?php echo e($similerArticle->tittle); ?></a></h2>
                                                                <div class="zm-post-meta">
                                                                    <ul>
                                                                        <li class="s-meta"><a href="#"
                                                                                              class="zm-author"><?php echo e($similerArticle->user->name); ?></a></li>
                                                                        <li class="s-meta"><a href="#" class="zm-date">April
                                                                                18, 2016</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </article>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                            <!-- End similar post -->
                            <!-- Start Comment box  -->
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="review-area mt-50 ptb-70 border-top">
                                    <div class="post-title mb-40">
                                        <h2 class="h6 inline-block">Toplam Yorum
                                            Sayısı: <?php echo e($comments->count()); ?></h2>
                                    </div>
                                    <div class="review-wrap">
                                        <div class="review-inner">
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!-- Start Single Review -->
                                                <div class="single-review clearfix">
                                                    <div class="reviewer-img">
                                                        <img src="<?php echo e(asset($comment->user->avatar)); ?>" alt="">
                                                    </div>
                                                    <div class="reviewer-info">
                                                        <h4 class="reviewer-name"><a
                                                                href="#"><?php echo e($comment->user->name); ?></a></h4>
                                                        <span
                                                            class="date-time"><?php echo e(date("d-M-Y",strtotime($comment->created_at))); ?></span>
                                                        <p class="reviewer-comment"><?php echo e($comment->comment); ?></p>
                                                        <a href="#" class="reply-btn">Reply</a>
                                                    </div>
                                                </div>
                                                <!-- End Single Review -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Comment box  -->
                        <?php if(Auth::check()): ?>
                            <!-- Start comment form -->
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="comment-form-area">
                                        <div class="post-title mb-40">
                                            <h2 class="h6 inline-block">Yorum Yaz</h2>
                                        </div>
                                        <div class="form-wrap">
                                            <form>
                                                <div class="form-inner clearfix">

                                                    <div class="single-input">
                                                    <textarea class="textarea" name="comment"
                                                              placeholder="Yorumunuzu Girin"></textarea>
                                                    </div>
                                                    <button class="submit-button" data-id="<?php echo e($article->id); ?>"
                                                            id="sendComment" type="button">Yorum
                                                        Gönder
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- End comment form -->
                            <?php else: ?>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    Yorum Yapmak için <a href="<?php echo e(route("login")); ?>">Giriş Yapın</a> Kayıtlı geğilseniz <a
                                        href="<?php echo e(route("register")); ?>">Kayıt olun</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- End left side -->
                    <!-- Start Right sidebar -->
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 sidebar-warp columns">
                        <div class="row">

                            <!-- Start post layout E -->
                            <aside class="zm-post-lay-e-area col-sm-6 col-md-12 col-lg-12 ">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">En çok Yorum
                                                Yapılanlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">
                                        <?php $__currentLoopData = $mostcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostcomment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!-- Start single post layout E -->
                                                <article class="zm-post-lay-e zm-single-post clearfix">
                                                    <div class="zm-post-thumb f-left">
                                                        <a href="<?php echo e(route("frontend.article.index",["id"=>$mostcomment->article->id,"slug"=>$mostcomment->article->slug])); ?>"><img
                                                                src="<?php echo e(asset($mostcomment->article->image)); ?>"
                                                                alt="img"></a>
                                                    </div>
                                                    <div class="zm-post-dis f-right">
                                                        <div class="zm-post-header">
                                                            <h2 class="zm-post-title"><a
                                                                    href="<?php echo e(route("frontend.article.index",["id"=>$mostcomment->article->id,"slug"=>$mostcomment->article->slug])); ?>"><?php echo e($mostcomment->article->tittle); ?></a>
                                                            </h2>
                                                            <div class="zm-post-meta">
                                                                <ul>
                                                                    <li class="s-meta"><a
                                                                            href="<?php echo e(route("frontend.user.index",["id"=>$mostcomment->user->id,"name"=>$mostcomment->user->name])); ?>"
                                                                            class="zm-author"><?php echo e($mostcomment->user->name); ?></a>
                                                                    </li>
                                                                    <li class="s-meta"><a href="#"
                                                                                          class="zm-date"><?php echo e(date("d-M-Y",strtotime($mostcomment->created_at))); ?></a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </article>
                                                <!-- Start single post layout E -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                            <!-- End post layout E -->
                            <aside class="zm-post-lay-f-area col-sm-6 col-md-12 col-lg-12 mt-70">
                                <div class="row mb-40">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="section-title">
                                            <h2 class="h6 header-color inline-block uppercase">Son Yorumlar</h2>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="zm-posts">

                                        <?php $__currentLoopData = $lastComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!-- Start single post layout F -->
                                                <div class="zm-post-lay-f zm-single-post clearfix">
                                                    <div class="zm-post-dis">
                                                        <p>
                                                            <a href="<?php echo e(route("frontend.user.index",["id"=>$lastComment->user->id,"name"=>$lastComment->user->name])); ?>"><?php echo e($lastComment->user->name); ?> </a>
                                                            -
                                                            <em>“ <?php echo e(str_limit(strip_tags($lastComment->comment),$limit=100,$end="...")); ?>

                                                                ” </em><a
                                                                href="<?php echo e(route("frontend.article.index",["id"=>$lastComment->article->id,"slug"=>$lastComment->article->slug])); ?>">
                                                                <strong>on
                                                                    <?php echo e($lastComment->article->tittle); ?></strong></a>
                                                        </p>
                                                    </div>
                                                </div>
                                                <!-- End single post layout F -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                    <!-- End Right sidebar -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>
    <script>


        $("#sendComment").on("click", function () {
            var button = $(this);

            $(".has-error").removeClass("has-error");
            $(".label-danger").remove();

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });


            $.ajax({
                type: "post",
                url: "<?php echo e(route("frontend.article.comment")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id"),
                    comment: $("[name=comment]").val(),
                },
                success: function (response) {
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });
                },
                error: function (response) {
                    swal.close();

                    $.each(response.responseJSON.errors, function (k, v) {
                        $.each(v, function (kk, vv) {
                            $("[name='" + k + "']").parent().addClass("has-error");
                            $("[name='" + k + "']").parent().append(" <span class=\"label label-danger\">" + vv + "</span>");
                        })
                    });
                }
            })
        })

    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>