<?php $__env->startSection("content"); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Yeni Kategori Ekle</h5>
                </div>
                <div class="widget-content nopadding">
                    <form id="settingForm" class="form-horizontal">


                        <div class="control-group">
                            <label class="control-label">Üst Kategori</label>
                            <div class="controls">
                                <select class="span11" name="ust_id" id="">
                                    <option value="" selected>Üst Kategori</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->tittle); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Kategori Başlığı</label>
                            <div class="controls">
                                <input type="text" name="tittle" class="span11"/>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Kategori Açıklaması</label>
                            <div class="controls">
                                <input type="text" name="description" class="span11"/>
                            </div>
                        </div>


                        <div class="form-actions text-center">
                            <button type="button" id="categoryAdd" class="btn btn-success">Kategori Ekle</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>

    <script>


        $("#categoryAdd").on("click", function () {


            $(".has-error").removeClass("has-error");
            $(".label-danger").remove();

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            $.ajax({
                type: "post",
                url: "<?php echo e(route("backend.categories.store")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    tittle: $("[name=tittle]").val(),
                    ust_id: $("[name=ust_id]").val(),
                    description: $("[name=description]").val(),
                },

                success: function (response) {
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });


                },
                error: function (response) {
                    swal.close();

                    $.each(response.responseJSON.errors, function (k, v) {
                        $.each(v, function (kk, vv) {
                            $("[name='" + k + "']").parent().addClass("has-error");
                            $("[name='" + k + "']").parent().append(" <span class=\"label label-danger\">" + vv + "</span>");
                        })
                    });

                }
            })
        })

        /* Yüklenen resmi anlık olarak görmek için */
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#logoImageShow').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#logoImage").change(function () {
            readURL(this);
        });
        /* /Yüklenen resmi anlık olarak görmek için */
    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>