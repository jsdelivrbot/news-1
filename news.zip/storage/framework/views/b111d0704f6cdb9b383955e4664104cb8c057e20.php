<?php $__env->startSection("content"); ?>

    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5> Kategori Düzenle: <?php echo e($category->tittle); ?></h5>
                </div>
                <div class="widget-content nopadding">
                    <form id="settingForm" class="form-horizontal">


                        <div class="control-group">
                            <label class="control-label">Üst Kategori</label>
                            <div class="controls">
                                <select class="span11" name="ust_id" id="">


                                    <option <?php if($category->ust_id ==null): ?>selected <?php endif; ?> value="">Üst Kategory</option>

                                    <?php $__currentLoopData = $allcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($allcategory->id==$category->ust_id): ?> selected
                                                <?php endif; ?>  value="<?php echo e($allcategory->id); ?>"><?php echo e($allcategory->tittle); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Kategori Başlığı</label>
                            <div class="controls">
                                <input type="text" name="tittle" value="<?php echo e($category->tittle); ?>" class="span11"/>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Kategori Açıklaması</label>
                            <div class="controls">
                                <input type="text" name="description" value="<?php echo e($category->description); ?>"
                                       class="span11"/>
                            </div>
                        </div>


                        <div class="form-actions text-right">
                            <button type="button" id="categoryUpdate" data-id="<?php echo e($category->id); ?>"
                                    class="btn btn-success">Kategori Güncelle
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>

    <script>

        $("#categoryUpdate").on("click", function () {
            var button = $(this);

            $(".has-error").removeClass("has-error");
            $(".label-danger").remove();

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            $.ajax({
                type: "post",
                url: "<?php echo e(route("backend.categories.update")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id"),
                    tittle: $("[name=tittle]").val(),
                    ust_id: $("[name=ust_id]").val(),
                    description: $("[name=description]").val(),
                },
                success: function (response) {
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });


                },
                error: function (response) {
                    swal.close();

                    $.each(response.responseJSON.errors, function (k, v) {
                        $.each(v, function (kk, vv) {
                            $("[name='" + k + "']").parent().addClass("has-error");
                            $("[name='" + k + "']").parent().append(" <span class=\"label label-danger\">" + vv + "</span>");
                        })
                    });

                }
            })
        })


    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.backend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>